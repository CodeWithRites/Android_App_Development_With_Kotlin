  package com.example.implicit_explicit

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    @SuppressLint("UseKtx")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Explicit Intent button
        val btnExplicit = findViewById<Button>(R.id.btnExplicit)
        btnExplicit.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

        // Implicit Intent button
        val btnImplicit = findViewById<Button>(R.id.btnImplicit)
        btnImplicit.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("https://www.geeksforgeeks.org/courses/devops-live?source=google&medium=cpc&device=c&keyword=geeksforgeeks%20devops&matchtype=b&campaignid=19646466219&adgroup=179841663041&gad_source=1&gad_campaignid=19646466219&gbraid=0AAAAAC9yBkBpg2o6ZNMjatddBJGzWssfk&gclid=Cj0KCQjwh5vFBhCyARIsAHBx2wyxnkjfdsU4t8Ek739yMhtCRAruwaxL0-ALi7okUNrOeibt9RB5cfYaAoTyEALw_wcB")
            startActivity(intent)
        }
    }
}
