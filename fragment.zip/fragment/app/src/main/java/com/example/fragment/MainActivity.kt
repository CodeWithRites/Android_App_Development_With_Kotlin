package com.example.fragment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnNews = findViewById<Button>(R.id.btnNews)
        val btnSports = findViewById<Button>(R.id.btnSports)
        val btnEntertainment = findViewById<Button>(R.id.btnEntertainment)

        // Show NewsFragment by default
        replaceFragment(NewsFragment())

        btnNews.setOnClickListener {
            replaceFragment(NewsFragment())
        }

        btnSports.setOnClickListener {
            replaceFragment(SportsFragment())
        }

        btnEntertainment.setOnClickListener {
            replaceFragment(EntertainmentFragment())
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}
