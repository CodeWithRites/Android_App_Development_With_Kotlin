package com.example.sqllite_crud
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


class DatabaseHelper(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,SURNAME TEXT,MARKS INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, i: Int, i1: Int) {
        db.execSQL("DROP TABLE if EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertData(name: String?, surname: String?, marks: String?): Boolean {
        val db = this.readableDatabase       //opens the app’s SQLite database in read-only mode (or writable if possible) and returns a SQLiteDatabase object for reading data.
        val contentValues = ContentValues() //container to store data in key value pair
        contentValues.put(COL_2, name)      //put() inserts a value into the ContentValues
        contentValues.put(COL_3, surname)
        contentValues.put(COL_4, marks)
        val result = db.insert(TABLE_NAME, null, contentValues)
        return if (result == -1L) false else true
    }

    fun getData():Cursor{
        val db = this.readableDatabase
        return db.rawQuery("Select * from $TABLE_NAME", null)
    }

    fun updateData(id: String, name: String?, surname: String?, marks: String?): Boolean {
        val db = this.writableDatabase      //opens (or creates) the app’s SQLite database in write mode and returns a SQLiteDatabase object for performing insert, update, or delete operations.
        val contentValues = ContentValues() //container to store data in key value pair
        contentValues.put(COL_1, id)        //put() inserts a value into the ContentValues
        contentValues.put(COL_2, name)
        contentValues.put(COL_3, surname)
        contentValues.put(COL_4, marks)
        db.update(TABLE_NAME, contentValues, " id = ? ", arrayOf(id))
        return false
    }
    //This function opens the database in read mode and returns a Cursor containing all rows and columns from the specified table.
    fun delData(id: String): Int {
        val db = this.readableDatabase
        return db.delete(TABLE_NAME, " id = ? ", arrayOf(id))
    }


    companion object {
        const val DATABASE_NAME = "students.db"
        const val TABLE_NAME = "s1_table"
        const val COL_1 = "ID"
        const val COL_2 = "NAME"
        const val COL_3 = "SURNAME"
        const val COL_4 = "MARKS"
    }
}