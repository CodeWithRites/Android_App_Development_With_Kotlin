package com.example.sqllite_crud

import android.database.Cursor
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    var myDb: DatabaseHelper? = null
    var etName: EditText? = null
    var etSurname: EditText? = null
    var etMarks: EditText? = null
    var etId: EditText? = null
    var addBtn: Button? = null
    var vBtn: Button? = null
    var updateBtn: Button? = null
    var delBtn: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        myDb = DatabaseHelper(this)
        etId = findViewById<View>(R.id.editTextId) as EditText
        etName = findViewById<View>(R.id.editTextName) as EditText
        etSurname = findViewById<View>(R.id.editTextSurname) as EditText
        etMarks = findViewById<View>(R.id.editTextMarks) as EditText
        addBtn = findViewById<View>(R.id.btnAdd) as Button
        vBtn = findViewById<View>(R.id.btnView) as Button
        updateBtn = findViewById<View>(R.id.btnUpdate) as Button
        delBtn = findViewById<View>(R.id.btnDelete) as Button
        adData()
        viewData()
        updateData()
        dellData()
    }

    fun adData() {
        addBtn!!.setOnClickListener {
            val isInserted: Boolean = myDb!!.insertData(
                etName!!.text.toString(),
                etSurname!!.text.toString(),
                etMarks!!.text.toString()
            )
            if (isInserted == true)
                Toast.makeText(
                    this@MainActivity,
                    "Data  Inserted",
                    Toast.LENGTH_LONG
                ).show()
            else Toast.makeText(this@MainActivity, "Data not Inserted", Toast.LENGTH_LONG)
                .show()
        }
    }

    fun viewData() {
        vBtn!!.setOnClickListener(View.OnClickListener {
            val res: Cursor = myDb!!.getData()
            if (res.count == 0) {
                //show message
                showMsg("Error", "No data Found")
                return@OnClickListener
            }
            val buffer = StringBuffer()
            while (res.moveToNext()) {
                buffer.append(
                    """
                        ID :${res.getString(0)}
                        
                        """.trimIndent()
                )
                buffer.append(
                    """
                        NAME :${res.getString(1)}
                        
                        """.trimIndent()
                )
                buffer.append(
                    """
                        SURNAME :${res.getString(2)}
                        
                        """.trimIndent()
                )
                buffer.append(
                    """
                        MARKS :${res.getString(3)}
                        
                        
                        """.trimIndent()
                )
            }
            //show alldata
            showMsg("Data", buffer.toString())
        })
    }

    fun showMsg(title: String?, message: String?) {
        val builder = AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.show()
    }

    fun dellData() {
        delBtn!!.setOnClickListener {
            val delRows: Int = myDb!!.delData(etId!!.text.toString())
            if (delRows > 0) Toast.makeText(this@MainActivity, "Data Deleted", Toast.LENGTH_LONG)
                .show() else Toast.makeText(
                this@MainActivity,
                "Data  not Deleted",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun updateData() {
        updateBtn!!.setOnClickListener {
            val isUpdate: Boolean = myDb!!.updateData(
                etId!!.text.toString(),
                etName!!.text.toString(),
                etSurname!!.text.toString(),
                etMarks!!.text.toString()
            )
            if (isUpdate == true) Toast.makeText(
                this@MainActivity,
                "Data Updated",
                Toast.LENGTH_LONG
            ).show() else Toast.makeText(this@MainActivity, "Data  not Updated", Toast.LENGTH_LONG)
                .show()
        }
    }
}