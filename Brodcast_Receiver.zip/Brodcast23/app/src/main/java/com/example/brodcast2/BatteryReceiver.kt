package com.example.brodcast2

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.widget.TextView

class BatteryReceiver(
    private val batteryText: TextView,
    private val statusText: TextView
) : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        intent?.let {
            val level = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = it.getIntExtra(BatteryManager.EXTRA_STATUS, -1)

            if (level >= 0 && scale > 0) {
                val batteryPct = (level / scale.toFloat() * 100).toInt()
                batteryText.text = "🔋 Battery Level: $batteryPct%"
            } else {
                batteryText.text = "Battery info not available ⚡"
            }

            // Charging status
            val statusString = when (status) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "⚡ Charging"
                BatteryManager.BATTERY_STATUS_FULL -> "✅ Full"
                else -> "Not Charging"
            }
            statusText.text = statusString
        }
    }
}
