package com.example.brodcast2

import android.annotation.SuppressLint
import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var batteryStatus: TextView
    private lateinit var chargingStatus: TextView
    private lateinit var healthStatus: TextView
    private lateinit var techStatus: TextView
    private lateinit var tempStatus: TextView
    private lateinit var batteryReceiver: BatteryReceiver

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        batteryStatus = findViewById(R.id.tvBattery)
        chargingStatus = findViewById(R.id.tvCharging)
        healthStatus = findViewById(R.id.tvHealth)
        techStatus = findViewById(R.id.tvTechnology)
        tempStatus = findViewById(R.id.tvTemperature)

        batteryReceiver = BatteryReceiver(batteryStatus, chargingStatus)

        // Sticky intent to get initial battery status
        val stickyIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        stickyIntent?.let {
            batteryReceiver.onReceive(this, it)
        }

        // Register for ongoing updates (plug/unplug events)
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(batteryReceiver, filter)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(batteryReceiver)
    }
}
