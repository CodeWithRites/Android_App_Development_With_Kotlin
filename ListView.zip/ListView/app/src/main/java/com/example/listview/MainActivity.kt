package com.example.listview

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var lv: ListView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lv = findViewById(R.id.lview)

        // Data source
        val names = arrayOf("C", "JAVA", "PYTHON", "C++", "HTML", "PHP")

        // Adapter
        val arrayAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            names
        )

        lv.adapter = arrayAdapter

        // Click listener
        lv.setOnItemClickListener { _, _, i, _ ->
            Toast.makeText(
                this@MainActivity,
                "THIS IS: ${names[i]}",
                Toast.LENGTH_SHORT
            ).show()
            }
        }
    }