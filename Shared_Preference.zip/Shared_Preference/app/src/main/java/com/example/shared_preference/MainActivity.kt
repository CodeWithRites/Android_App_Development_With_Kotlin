package com.example.shared_preference

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var btnSave: Button
    private lateinit var btnView: Button
    private lateinit var btnExit: Button

    private val PREF_NAME = "UserPref"
    private val KEY_NAME = "username"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Window Insets Fix
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        editTextName = findViewById(R.id.editTextName)
        btnSave = findViewById(R.id.btnSave)
        btnView = findViewById(R.id.btnView)
        btnExit = findViewById(R.id.exitButton)

        // Save data to SharedPreferences
        btnSave.setOnClickListener {
            val name = editTextName.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter your name!", Toast.LENGTH_SHORT).show()
            } else {
                val sharedPref = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val editor = sharedPref.edit()
                editor.putString(KEY_NAME, name)
                editor.apply()
                Toast.makeText(this, "Data Saved Successfully!", Toast.LENGTH_SHORT).show()
                editTextName.text.clear()
            }
        }

        // Retrieve data
        btnView.setOnClickListener {
            val sharedPref = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val savedName = sharedPref.getString(KEY_NAME, null)
            if (savedName != null) {
                Toast.makeText(this, "Stored Name: $savedName", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "No data found!", Toast.LENGTH_SHORT).show()
            }
        }

        // Exit App with AlertDialog
        btnExit.setOnClickListener {
            showExitDialog()
        }
    }

    private fun showExitDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setIcon(android.R.drawable.ic_dialog_alert)
        builder.setTitle("Exit App")
        builder.setMessage("Are you sure you want to exit?")
        builder.setPositiveButton("Yes") { _, _ ->
            finish()
        }
        builder.setNegativeButton("No") { dialog, _ ->
            dialog.dismiss()
        }
        builder.create().show()
    }
}
